#include "Observer.h"

#pragma warning(disable:4996)

Observer::Observer() {

}

Observer::~Observer() {

}