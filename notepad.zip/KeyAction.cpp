#include "KeyAction.h"

#pragma warning(disable:4996)

KeyAction::KeyAction(CWnd* parent)
	:Action(parent) {

}

KeyAction::~KeyAction() {

}