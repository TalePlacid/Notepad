//{{NO_DEPENDENCIES}}
// Microsoft Visual C++���� ������ ���� �����Դϴ�.
// notepad250410.rc���� ���ǰ� �ֽ��ϴ�.
//
#define IDR_MENU_MAIN                   101
#define ID_MENU_NEW                     40003
#define ID_MENU_OPEN                    40004
#define ID_MENU_SAVE                    40005
#define ID_MENU_SAVEAS                  40006
#define ID_MENU_PREVIEW                 40007
#define ID_40008                        40008
#define ID_MENU_PRINT                   40009
#define ID_MENU_CLOSE                   40010
#define ID_MENU_EXIT                    40011
#define ID_MENU_FINDPREVIOUS            40023
#define ID_MENU_FINDNEXT                40024
#define ID_MENU_FIND                    40025
#define ID_MENU_CHANGE                  40026
#define ID_MENU_REPLACE                 40027
#define ID_MENU_GOTO                    40028
#define ID_MENU_DELETE                  40029
#define ID_MENU_PASTE                   40030
#define ID_MENU_COPY                    40031
#define ID_MENU_CUT                     40032
#define ID_MENU_UNDO                    40033
#define ID_MENU_REDO                    40034
#define ID_MENU_                        40036
#define ID_MENU_N                       40037
#define ID_MENU_NEWWINDOW               40038
#define ID_MENU_FORM                    40039
#define ID_MENU_AUTO                    40042
#define ID_MENU_FONT                    40043
#define ID_MENU_ZOOMIN                  40046
#define ID_MENU_ZOOMOUT                 40048
#define ID_MENU_STATUS                  40050
#define ID_MENU_INFO                    40052
#define ID_MENU_ZOOMDEFAULT             40053
#define ID_MENU_AUTOWRAP                40054
#define ID_COMMAND_ERASE                50001
#define ID_COMMAND_PASTE				50002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40055
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
