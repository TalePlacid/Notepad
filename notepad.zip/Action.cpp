#include <afxwin.h>
#include "Action.h"

#pragma warning(disable:4996)

Action::Action(CWnd* parent) {
	this->parent = parent;
}

Action::~Action() {

}