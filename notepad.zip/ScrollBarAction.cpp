#include <afxwin.h>
#include "ScrollBarAction.h"

#pragma warning(disable:4996)

ScrollBarAction::ScrollBarAction(CWnd* parent)
	:Action(parent) {

}

ScrollBarAction::~ScrollBarAction() {

}
